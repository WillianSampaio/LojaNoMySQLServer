package br.com.senaibrasilia.projetofinal.dao;

public class ClienteDAO {
	public void cadastrar() {
		//persist
	}
	public void Alterar() {
		//marge
	}
	public void pesquisarPorCodigo() {
		//find
	}
	public void pesquisaPorNome() {
		//?
	}
	public void pesquisarTodos(){
		//query -JPQL
		//ArrayList - List
		//Lambda - Java8
	}
}
